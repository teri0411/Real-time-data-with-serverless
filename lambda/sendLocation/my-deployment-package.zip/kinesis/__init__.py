# -*- coding: utf-8 -*-

from __future__ import unicode_literals

__title__ = "kinesis"
__author__ = "Dave Gallant"
__license__ = "Apache 2.0"
__copyright__ = "(c) 2019 Dave Gallant"
